package model;

public class Sensor {
	private String name;
	
	public Sensor(String name) {
		this.name = name;
	}
	
	public String getName(){
		return name;
	}
	
	public String toString(){
		return name;
	}
}
